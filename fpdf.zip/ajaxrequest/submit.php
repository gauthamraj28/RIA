<?php

$fname = $_POST['fname'];
$lname = $_POST['surname'];

echo "$fname $lname";

?>