<script src = "http://code.jquery.com/jquery-1.11.1.min.js"></script>
<script src = "script.js"></script>

<div>
	<input type = "text" id = "fname">
	<input type = "text" id = "surname">
	<button id = "formsubmit">Send Data</button><br>
	<div id="response">
	<p ></p>
	</div>
	<textarea  style = "width: 200px; height: 100px; resize: none;"></textarea>
</div>